<?php

namespace App\Module\Catalog\Collection;

use App\Module\Catalog\Model\ProductFileViewModel;
use App\Traits\CollectionTrait;

class ProductFileViewCollection extends ProductFileViewModel
{
    use CollectionTrait;
}