<?php

namespace App;

class Handler {

    public function __construct()
    {
    }

}
