<?php

namespace App\Request;

use App\Request\UserRequest;

class EmptyRequest extends UserRequest
{
}