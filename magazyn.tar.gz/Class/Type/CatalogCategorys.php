<?php

namespace App\Type;

use App\Traits\CollectionTrait;

class CatalogCategorys extends CatalogCategory
{
    use CollectionTrait;
}