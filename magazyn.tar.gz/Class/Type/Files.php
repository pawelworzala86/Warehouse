<?php

namespace App\Type;

use App\Traits\CollectionTrait;

class Files extends File
{
    use CollectionTrait;
}