<?php

namespace App\Type;

use App\Traits\CollectionTrait;

class UUIDs extends UUID
{
    use CollectionTrait;
}