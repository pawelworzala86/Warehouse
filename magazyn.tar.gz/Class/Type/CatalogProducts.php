<?php

namespace App\Type;

use App\Traits\CollectionTrait;

class CatalogProducts extends CatalogProduct
{
    use CollectionTrait;
}