<?php

namespace App\Type;

use App\Traits\CollectionTrait;

class FilesResponse extends FileResponse
{
    use CollectionTrait;
}