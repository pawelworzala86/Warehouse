<?php

namespace App\Type;

use App\Traits\CollectionTrait;

class Filters extends Filter
{
    use CollectionTrait;
}